/**
 * 03-star-trail.js - Sparkle trail that follows the cursor.
 */
(function(){
  if(window.matchMedia&&window.matchMedia("(prefers-reduced-motion: reduce)").matches)return;
  var cv=document.getElementById("stars"),ctx=cv.getContext("2d"),W=0,H=0,dpr=Math.min(window.devicePixelRatio||1,2);
  function size(){W=window.innerWidth;H=window.innerHeight;cv.width=W*dpr;cv.height=H*dpr;ctx.setTransform(dpr,0,0,dpr,0,0);}
  size();window.addEventListener("resize",size);
  var ps=[],running=false,lx=-100,ly=-100,cols=["#ffffff","#ffd6e0","#ff9aa8","#ffe9a8"];
  function spawn(x,y){
    ps.push({x:x+(Math.random()-.5)*8,y:y+(Math.random()-.5)*8,vx:(Math.random()-.5)*.8,vy:Math.random()*.7+.2,
      s:3+Math.random()*5,life:1,dec:.014+Math.random()*.014,rot:Math.random()*6.28,vr:(Math.random()-.5)*.12,c:cols[(Math.random()*cols.length)|0]});
    if(ps.length>140)ps.shift();
    if(!running){running=true;requestAnimationFrame(tick);}
  }
  function star(p){
    var s=p.s*(.5+p.life*.5),i=s*.28;
    ctx.save();ctx.translate(p.x,p.y);ctx.rotate(p.rot);
    ctx.globalAlpha=Math.max(0,p.life);ctx.fillStyle=p.c;ctx.shadowColor=p.c;ctx.shadowBlur=6;
    ctx.beginPath();
    for(var k=0;k<4;k++){
      var a=k*Math.PI/2;
      ctx.lineTo(Math.cos(a)*s,Math.sin(a)*s);
      ctx.lineTo(Math.cos(a+Math.PI/4)*i,Math.sin(a+Math.PI/4)*i);
    }
    ctx.closePath();ctx.fill();ctx.restore();
  }
  function tick(){
    ctx.clearRect(0,0,W,H);
    for(var k=ps.length-1;k>=0;k--){
      var p=ps[k];p.x+=p.vx;p.y+=p.vy;p.vy+=.012;p.rot+=p.vr;p.life-=p.dec;
      if(p.life<=0){ps.splice(k,1);continue;}
      star(p);
    }
    if(ps.length)requestAnimationFrame(tick);else{running=false;ctx.clearRect(0,0,W,H);}
  }
  window.addEventListener("pointermove",function(e){
    var dx=e.clientX-lx,dy=e.clientY-ly;
    if(dx*dx+dy*dy<64)return;
    lx=e.clientX;ly=e.clientY;
    spawn(lx,ly);
    if(Math.random()<.5)spawn(lx,ly);
  },{passive:true});
})();
