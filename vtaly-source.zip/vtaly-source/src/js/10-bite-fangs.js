/**
 * 10-bite-fangs.js - Giant fangs fly out of the avatar and bite the name, swapping its font.
 */
(function(){
  var nm=document.getElementById("nm"),h2=nm.parentNode,pf=document.querySelector(".pfp"),gate=document.getElementById("gate"),fg=document.getElementById("bfg"),dim=document.getElementById("bdim");
  var reduce=window.matchMedia&&window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var fonts=[["UnifrakturCook","2.5rem",700],["Pirata One","2.6rem",400],["Creepster","2.4rem",400],["Nosifer","1.7rem",400],["New Rocker","2.5rem",400],["Metal Mania","2.4rem",400],["Eater","2.4rem",400],["Butcherman","2.4rem",400]],fi=0,busy=false;
  try{fonts.forEach(function(f){document.fonts.load('40px "'+f[0]+'"',"vtaly");});}catch(e){}
  function swap(){fi=(fi+1)%fonts.length;var f=fonts[fi];nm.style.setProperty("--nf",'"'+f[0]+'"');nm.style.setProperty("--ns",f[1]);nm.style.setProperty("--nw",f[2]);}
  function impact(ncx,ny){
    swap();
    h2.classList.add("hit");setTimeout(function(){h2.classList.remove("hit");},600);
    var fl=document.createElement("div");fl.className="sflash";fl.style.background="#ff2a2a";document.body.appendChild(fl);
    var w=document.createElement("div");w.className="wave";w.style.left=ncx+"px";w.style.top=ny+"px";w.style.borderColor="#ff1a1a";document.body.appendChild(w);
    requestAnimationFrame(function(){
      var r=nm.getBoundingClientRect();
      [-24,24].forEach(function(dx){var p=document.createElement("i");p.className="pm";p.style.left=(ncx+dx-r.left)+"px";p.style.top=(ny-r.top)+"px";nm.appendChild(p);setTimeout(function(){p.remove();},3100);});
    });
    setTimeout(function(){fl.remove();w.remove();},800);
  }
  function bite(){
    if(busy||!gate.classList.contains("hide"))return;
    busy=true;VT.busy=true;
    pf.classList.add("pop");setTimeout(function(){pf.classList.remove("pop");},1400);
    var nr=nm.getBoundingClientRect(),pr=pf.getBoundingClientRect(),W=window.innerWidth,H=window.innerHeight;
    var ncx=nr.left+nr.width/2,ny=nr.top+nr.height*.6;
    if(reduce){impact(ncx,ny);setTimeout(function(){busy=false;VT.busy=false;},800);return;}
    var pcx=pr.left+pr.width/2,pcy=pr.top+pr.height*.66,S1=Math.min(4.2,W/130),s=.9,D=2800;
    function tf(cx,cy,sc,rx){return "perspective(700px) translate("+(cx-60*sc)+"px,"+(cy-45*sc)+"px) scale("+sc+") rotateX("+rx+"deg)";}
    function tip(cx,ty,sc){return "perspective(700px) translate("+(cx-60*sc)+"px,"+(ty-88*sc)+"px) scale("+sc+") rotateX(0deg)";}
    fg.animate([
      {transform:tf(pcx,pcy,.1,0),opacity:0,offset:0},
      {transform:tf(pcx,pcy+8,.16,0),opacity:1,offset:.04,easing:"cubic-bezier(.2,1.5,.4,1)"},
      {transform:tf(pcx,pcy+14,.34,0),opacity:1,offset:.14,easing:"cubic-bezier(.6,0,1,.6)"},
      {transform:tf(W/2,H/2,S1,14),opacity:1,offset:.3},
      {transform:tf(W/2+10,H/2-6,S1*1.04,14),opacity:1,offset:.38},
      {transform:tf(W/2-8,H/2+4,S1,14),opacity:1,offset:.46,easing:"ease-in-out"},
      {transform:tip(ncx,ny-95,s),opacity:1,offset:.66,easing:"cubic-bezier(.75,0,1,.5)"},
      {transform:tip(ncx,ny+2,s),opacity:1,offset:.74},
      {transform:tip(ncx,ny+2,s),opacity:1,offset:.88},
      {transform:tip(ncx,ny-260,1.2),opacity:0,offset:1}
    ],{duration:D});
    dim.animate([{opacity:0,offset:0},{opacity:.85,offset:.24},{opacity:.85,offset:.48},{opacity:0,offset:.66},{opacity:0,offset:1}],{duration:D});
    setTimeout(function(){impact(ncx,ny);},D*.74);
    setTimeout(function(){busy=false;VT.busy=false;},D+100);
  }
  pf.addEventListener("click",bite);
  document.addEventListener("vtopen",function(){setTimeout(bite,5200);});
  setInterval(bite,17000);
})();
