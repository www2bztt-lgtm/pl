/**
 * 13-audio-reactive.js - Web Audio analyser: equalizer, beat pulse, bat speed, tab-title cycling.
 */
(function(){
  var au=document.getElementById("au"),root=document.documentElement,eq=document.querySelector(".eq"),bars=eq.querySelectorAll("i"),fl=document.getElementById("bflash");
  var ac=null,an=null,data=null,started=false,avg=0,lastBeat=0,lvl=0,beat=0;
  function setup(){
    if(started)return;started=true;
    try{
      var AC=window.AudioContext||window.webkitAudioContext;ac=new AC();
      var src=ac.createMediaElementSource(au);an=ac.createAnalyser();an.fftSize=256;an.smoothingTimeConstant=.7;
      var gn=ac.createGain();gn.gain.value=VT.muted?0:1;au.muted=false;VT.gain=gn;src.connect(an);an.connect(gn);gn.connect(ac.destination);data=new Uint8Array(an.frequencyBinCount);eq.classList.add("real");
    }catch(e){ac=null;an=null;}
  }
  function wake(){setup();if(ac&&ac.state==="suspended")ac.resume();}
  function band(a,b){var s=0;for(var i=a;i<b;i++)s+=data[i];return s/((b-a)*255);}
  function loop(now){
    if(an&&!au.paused){
      an.getByteFrequencyData(data);
      var bass=band(0,4),v=[bass,band(4,12),band(12,40),band(40,100)];
      lvl+=(bass-lvl)*.35;avg+=(bass-avg)*.02;
      if(bass>avg*1.28&&bass>.45&&now-lastBeat>230){lastBeat=now;beat=1;}
      beat*=.88;VT.level=lvl;
      for(var i=0;i<4;i++)bars[i].style.transform="scaleY("+(.15+Math.min(1,v[i]*1.5)*.85).toFixed(2)+")";
    }else{
      beat*=.9;VT.level=0;
      if(an)for(var j=0;j<4;j++)bars[j].style.transform="scaleY(.2)";
    }
    root.style.setProperty("--beat",Math.min(1,beat).toFixed(3));
    fl.style.opacity=(Math.min(1,beat)*.2).toFixed(3);
    requestAnimationFrame(loop);
  }
  au.addEventListener("play",wake);
  document.getElementById("gate").addEventListener("click",wake);
  window.addEventListener("pointerdown",function(){if(ac&&ac.state==="suspended")ac.resume();},{passive:true});
  requestAnimationFrame(loop);
  var tt=["vtaly \u{1F987}","dm for promo ae 2026","vtaly \u{1FA78}"],ti=0;
  setInterval(function(){document.title=tt[ti++%tt.length];},2500);
})();
