/**
 * 08-lightning-strike.js - Lightning bolt that hits the name and recolors it.
 */
(function(){
  if(window.matchMedia&&window.matchMedia("(prefers-reduced-motion: reduce)").matches)return;
  var nm=document.getElementById("nm"),h2=nm.parentNode,gate=document.getElementById("gate"),idx=0,last=0;
  var pal=[["#c9a8ff","#6a2bff","rgba(150,90,255,.95)","#b58cff"],["#ff9a9a","#d40000","rgba(255,40,40,.95)","#ff4d4d"],["#fff2a8","#ffb300","rgba(255,190,40,.95)","#ffd24d"],["#a9f3ff","#1aa6ff","rgba(60,180,255,.95)","#59c8ff"],["#ffb8e6","#ff2fa0","rgba(255,60,170,.95)","#ff6bc1"],["#e4e4e4","#8a8a8a","rgba(255,40,40,.9)","#ff4d4d"]];
  function path(x0,y0,x1,y1,n,j){var d="M"+x0.toFixed(1)+" "+y0.toFixed(1);for(var i=1;i<=n;i++){var t=i/n;d+=" L"+(x0+(x1-x0)*t+(i<n?(Math.random()-.5)*j:0)).toFixed(1)+" "+(y0+(y1-y0)*t).toFixed(1);}return d;}
  function strike(){
    if(!gate.classList.contains("hide")||VT.busy)return;
    var now=Date.now();if(now-last<1500)return;last=now;
    var r=nm.getBoundingClientRect(),cx=r.left+r.width/2,W=window.innerWidth,H=window.innerHeight;
    var p=pal[idx++%pal.length],x0=Math.max(20,Math.min(W-20,cx+(Math.random()-.5)*260)),tx=cx+(Math.random()-.5)*24,ty=r.top+r.height*.45;
    var n=Math.max(6,Math.round(ty/26)),main=path(x0,-10,tx,ty,n,44);
    var bx=x0+(tx-x0)*.45,by=ty*.45,side=Math.random()<.5?-1:1,br=path(bx,by,bx+side*70,by+60,4,22);
    var s='<svg class="strike" viewBox="0 0 '+W+' '+H+'" preserveAspectRatio="none" aria-hidden="true"><g fill="none" stroke-linejoin="round" stroke-linecap="round">';
    [[main,9,p[3],.45],[main,3.5,p[0],1],[main,1.6,"#fff",1],[br,5,p[3],.35],[br,1.4,"#fff",.9]].forEach(function(a){s+='<path d="'+a[0]+'" stroke="'+a[2]+'" stroke-width="'+a[1]+'" opacity="'+a[3]+'"/>';});
    s+='</g></svg><div class="sflash"></div>';
    var box=document.createElement("div");box.innerHTML=s;document.body.appendChild(box);
    var w=document.createElement("div");w.className="wave";w.style.left=cx+"px";w.style.top=(r.top+r.height/2)+"px";w.style.borderColor=p[3];document.body.appendChild(w);
    setTimeout(function(){nm.style.setProperty("--c1",p[0]);nm.style.setProperty("--c2",p[1]);nm.style.setProperty("--gl",p[2]);},90);
    h2.classList.add("hit");
    setTimeout(function(){h2.classList.remove("hit");},600);
    setTimeout(function(){box.remove();w.remove();},800);
  }
  document.addEventListener("vtopen",function(){setTimeout(strike,1500);});
  setTimeout(function(){strike();setInterval(strike,7000);},6350);
})();
