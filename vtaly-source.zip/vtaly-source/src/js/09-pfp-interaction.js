/**
 * 09-pfp-interaction.js - Profile-picture click reaction (jolt, ring, fangs).
 */
(function(){
  var pf=document.querySelector(".pfp");
  pf.addEventListener("click",function(){
    pf.classList.remove("jolt");void pf.offsetWidth;pf.classList.add("jolt","pop");
    var r=pf.getBoundingClientRect(),w=document.createElement("div");w.className="wave";
    w.style.left=(r.left+r.width/2)+"px";w.style.top=(r.top+r.height/2)+"px";w.style.borderColor="#ff1a1a";
    document.body.appendChild(w);
    setTimeout(function(){w.remove();},750);
    setTimeout(function(){pf.classList.remove("jolt","pop");},1200);
  });
})();
