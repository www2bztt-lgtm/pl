/**
 * 05-banner-3d.js - Pointer parallax, pop-out and vampire emergence for the banner.
 */
(function(){
  var card=document.querySelector(".card"),bn=document.getElementById("bn"),vp=document.getElementById("vamp"),gate=document.getElementById("gate");
  window.addEventListener("pointermove",function(e){
    card.style.setProperty("--px",((e.clientX/window.innerWidth-.5)*2).toFixed(3));
    card.style.setProperty("--py",((e.clientY/window.innerHeight-.5)*2).toFixed(3));
  },{passive:true});
  function go(){
    bn.classList.remove("pop");vp.classList.remove("emerge");void bn.offsetWidth;
    bn.classList.add("pop");vp.classList.add("emerge");
  }
  document.addEventListener("vtopen",go);
  bn.addEventListener("click",go);
})();
