/**
 * 00-state.js - Shared state. Everything cross-file lives on window.VT (no stray globals).
 */
window.VT = { level: 0, busy: false, gain: null, muted: false };
