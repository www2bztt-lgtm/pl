/**
 * 02-bats.js - Ambient bat canvas plus the two bat orbits around the name.
 */
(function(){
  var cv=document.getElementById("bats"),ctx=cv.getContext("2d"),W=0,H=0,dpr=Math.min(window.devicePixelRatio||1,2);
  function size(){W=window.innerWidth;H=window.innerHeight;cv.width=W*dpr;cv.height=H*dpr;ctx.setTransform(dpr,0,0,dpr,0,0);}
  size();window.addEventListener("resize",size);
  var N=Math.max(24,Math.min(46,Math.round(W*H/22000))),bats=[];
  for(var i=0;i<N;i++){
    var s=3.5+Math.random()*4.5;
    bats.push({x:Math.random()*W,y:Math.random()*H,s:s,
      vx:(Math.random()<.5?-1:1)*(.5+Math.random()*1.3)*(1+(8-s)*.08),
      vy:(Math.random()-.5)*.6,ph:Math.random()*6.28,fs:.22+Math.random()*.16,
      a:.55+Math.random()*.45,t:Math.random()*1000});
  }
  function bat(b){
    var f=Math.sin(b.ph),s=b.s,tipY=-s*.55*f;
    ctx.save();
    ctx.translate(b.x,b.y+Math.sin(b.t*.05)*2);
    if(b.vx<0)ctx.scale(-1,1);
    ctx.globalAlpha=b.a;
    ctx.fillStyle="#ff2a2a";
    for(var k=0;k<2;k++){
      ctx.save();
      if(k)ctx.scale(-1,1);
      ctx.beginPath();
      ctx.moveTo(0,-s*.1);
      ctx.quadraticCurveTo(-s*.6,tipY-s*.35,-s*1.3,tipY);
      ctx.quadraticCurveTo(-s*1.0,tipY+s*.35,-s*.85,tipY*.5+s*.4);
      ctx.quadraticCurveTo(-s*.65,s*.2+tipY*.3,-s*.5,s*.5);
      ctx.quadraticCurveTo(-s*.25,s*.25,0,s*.45);
      ctx.closePath();ctx.fill();
      ctx.restore();
    }
    ctx.beginPath();ctx.ellipse(0,s*.1,s*.28,s*.5,0,0,6.283);ctx.fill();
    ctx.beginPath();ctx.moveTo(-s*.25,-s*.3);ctx.lineTo(-s*.2,-s*.7);ctx.lineTo(-s*.02,-s*.4);
    ctx.moveTo(s*.25,-s*.3);ctx.lineTo(s*.2,-s*.7);ctx.lineTo(s*.02,-s*.4);ctx.fill();
    ctx.restore();
  }
  var nameEl=document.getElementById("nm"),gate=document.getElementById("gate"),orb=[];
  for(var j=0;j<9;j++){orb.push({ang:j/9*6.283,sp:.018+Math.random()*.016,dir:j%2?1:-1,s:3.8+Math.random()*2.2,ph:Math.random()*6.28,fs:.3+Math.random()*.1,ro:Math.random()*16,t:Math.random()*100,a:.9});}
  function orbit(){
    if(gate.classList.contains("hide")===false)return;
    var r=nameEl.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2;
    for(var j=0;j<orb.length;j++){
      var o=orb[j];o.ang+=o.sp*o.dir*(1+(VT.level||0)*1.5);o.ph+=o.fs;o.t++;
      o.x=cx+(r.width/2+2+o.ro*.2)*Math.cos(o.ang);
      o.y=cy+(r.height/2-2+o.ro*.15)*Math.sin(o.ang);
      o.vx=-Math.sin(o.ang)*o.dir;
      bat(o);
    }
  }
  var ring=[];
  for(var q=0;q<8;q++){ring.push({ang:q/8*6.283,s:3.8,ph:q*.8,fs:.34,t:q*20,a:1});}
  var ringAng=0;
  function circle(){
    if(gate.classList.contains("hide")===false)return;
    var r=nameEl.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2,RX=r.width/2+10,RY=r.height/2+8;
    ringAng-=.022*(1+(VT.level||0)*2);
    for(var q=0;q<ring.length;q++){
      var o=ring[q],a=o.ang+ringAng;o.ph+=o.fs;o.t++;
      o.x=cx+RX*Math.cos(a);o.y=cy+RY*Math.sin(a);
      o.vx=Math.sin(a);
      bat(o);
    }
  }
  var still=window.matchMedia&&window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  function frame(){
    ctx.clearRect(0,0,W,H);
    for(var i=0;i<bats.length;i++){
      var b=bats[i];
      b.ph+=b.fs*(1+(VT.level||0));b.t++;
      b.vy+=(Math.random()-.5)*.12;
      if(b.vy>.9)b.vy=.9;if(b.vy<-.9)b.vy=-.9;
      var m=1+(VT.level||0)*1.6;b.x+=b.vx*m;b.y+=b.vy*m;
      if(b.x>W+20)b.x=-20;if(b.x<-20)b.x=W+20;
      if(b.y>H+20)b.y=-20;if(b.y<-20)b.y=H+20;
      bat(b);
    }
    orbit();
    circle();
    if(!still)requestAnimationFrame(frame);
  }
  frame();
})();
