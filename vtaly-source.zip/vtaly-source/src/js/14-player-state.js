/**
 * 14-player-state.js - Progress CSS variable and the body "playing" class.
 */
(function(){
  var au=document.getElementById("au"),pl=document.querySelector(".player");
  au.addEventListener("timeupdate",function(){if(au.duration)pl.style.setProperty("--prog",(au.currentTime/au.duration*100).toFixed(2));});
  au.addEventListener("play",function(){document.body.classList.add("playing");});
  au.addEventListener("pause",function(){document.body.classList.remove("playing");});
})();
