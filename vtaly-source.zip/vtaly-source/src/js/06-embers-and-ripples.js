/**
 * 06-embers-and-ripples.js - Rising embers, click shockwaves and the "playing" state class.
 */
(function(){
  var still=window.matchMedia&&window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var cv=document.getElementById("embers"),ctx=cv.getContext("2d"),W=0,H=0,dpr=Math.min(window.devicePixelRatio||1,2),E=[];
  function size(){W=window.innerWidth;H=window.innerHeight;cv.width=W*dpr;cv.height=H*dpr;ctx.setTransform(dpr,0,0,dpr,0,0);}
  size();window.addEventListener("resize",size);
  function mk(init){return{x:Math.random()*W,y:init?Math.random()*H:H+10,r:.6+Math.random()*2,vy:.25+Math.random()*.8,sw:Math.random()*6.28,ss:.01+Math.random()*.02,g:50+Math.random()*110,a:.3+Math.random()*.6};}
  for(var i=0;i<70;i++)E.push(mk(true));
  function tick(){
    ctx.clearRect(0,0,W,H);
    for(var i=0;i<E.length;i++){
      var p=E[i];p.y-=p.vy;p.sw+=p.ss;p.x+=Math.sin(p.sw)*.5;
      var f=Math.min(1,p.y/(H*.6));
      ctx.fillStyle="rgba(255,"+(p.g|0)+",40,"+(p.a*f*(.7+.3*Math.sin(p.sw*4)))+")";
      ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,6.283);ctx.fill();
      if(p.y<-10)E[i]=mk(false);
    }
    if(!still)requestAnimationFrame(tick);
  }
  tick();
  window.addEventListener("pointerdown",function(e){
    var w=document.createElement("div");w.className="wave";w.style.left=e.clientX+"px";w.style.top=e.clientY+"px";
    document.body.appendChild(w);setTimeout(function(){w.remove();},750);
  },{passive:true});
  var au=document.getElementById("au"),pl=document.querySelector(".player");
  au.addEventListener("play",function(){pl.classList.add("on");});
  au.addEventListener("pause",function(){pl.classList.remove("on");});
})();
