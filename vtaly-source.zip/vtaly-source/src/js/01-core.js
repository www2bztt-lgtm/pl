/**
 * 01-core.js - View counter, gate dismissal and basic play/pause.
 */
(function () {
  var views = 1;
  try {
    views = (parseInt(localStorage.getItem('views'), 10) || 0) + 1;
    localStorage.setItem('views', views);
  } catch (e) {}
  document.getElementById('v').textContent = views;
  document.getElementById('gv').textContent = views + ' views';

  var au = document.getElementById('au');
  var gate = document.getElementById('gate');
  var pp = document.getElementById('pp');
  var st = document.getElementById('st');
  var pr = document.getElementById('pr');

  function play() {
    au.play().catch(function () {});
  }
  au.addEventListener('play', function () {
    pp.textContent = '\u275a\u275a';
    st.textContent = 'Now playing';
  });
  gate.addEventListener('click', function () {
    gate.classList.add('hide');
    play();
  });
  pp.addEventListener('click', function () {
    if (au.paused) {
      play();
    } else {
      au.pause();
      pp.textContent = '\u25b6';
      st.textContent = 'Paused';
    }
  });
  au.addEventListener('timeupdate', function () {
    if (au.duration) pr.style.width = (au.currentTime / au.duration * 100) + '%';
  });
})();
