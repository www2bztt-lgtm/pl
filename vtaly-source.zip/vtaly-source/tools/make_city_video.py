import numpy as np, subprocess, math, random, os
from PIL import Image, ImageDraw, ImageFilter
W,H,FPS,T = 640,360,24,8
N = FPS*T; EW = W+80
TAU = 2*math.pi
rngn = np.random.default_rng(5)
yy,xx = np.mgrid[0:H,0:W].astype(np.float32); X=xx/W; Y=yy/H

# ---------- sky ----------
top=np.array([12,0,10],np.float32); hor=np.array([120,14,26],np.float32)
g=(Y**1.4)[...,None]
sky=top*(1-g)+hor*g
rs=random.Random(3)
stars=[(rs.randint(0,W-3),rs.randint(0,170),rs.randint(1,3),rs.random()) for _ in range(45)]
mx,my,MR=470,112,46
dm=np.sqrt((xx-mx)**2+(yy-my)**2)
glow=np.exp(-(dm/95.0)**2)[...,None]*np.array([130,10,16],np.float32)
disk=np.clip((MR-dm)/1.5,0,1)
rad=np.clip(dm/MR,0,1)[...,None]
mooncol=np.array([255,120,110],np.float32)*(1-rad)+np.array([160,16,28],np.float32)*rad
tex=(np.sin(xx*.21+yy*.13)+np.sin(xx*.09-yy*.27)+np.sin(xx*.33+yy*.05))/3
mooncol=mooncol*(1+.12*tex[...,None])

def comps(n,lo,hi,seed):
    r=np.random.default_rng(seed)
    return [(r.uniform(lo,hi)*r.choice([-1,1]),r.uniform(lo,hi)*r.choice([-1,1]),int(r.integers(1,3))*r.choice([-1,1]),r.uniform(0,6.28),r.uniform(.5,1)) for _ in range(n)]
def field(cs,Xa,Ya,ph):
    s=np.zeros_like(Xa);t=0
    for kx,ky,n,p,a in cs:
        s+=a*np.sin(TAU*(kx*Xa+ky*Ya)+TAU*n*ph+p);t+=a
    return s/t
FA=comps(8,1.0,4.0,1); FB=comps(5,.8,2.4,2); CA=comps(6,1.5,5.0,9)

# ---------- skylines ----------
def skyline(seed,base,hmin,hmax,wmin,wmax,color,spire,wins,winprob,fx=None):
    im=Image.new("RGBA",(EW,H+60),(0,0,0,0)); d=ImageDraw.Draw(im); r=random.Random(seed); x=0
    while x<EW:
        w=r.randint(wmin,wmax); h=r.randint(hmin,hmax); top=base-h
        d.rectangle([x,top,x+w,H+60],fill=color)
        roll=r.random()
        if roll<spire:
            d.polygon([(x,top),(x+w,top),(x+w/2,top-r.randint(16,38))],fill=color)
            if r.random()<.5: d.line([(x+w/2,top-30),(x+w/2,top-r.randint(44,64))],fill=color,width=2)
        elif roll<spire+.2:
            for cx in range(x,x+w-2,6): d.rectangle([cx,top-4,cx+3,top],fill=color)
        if wins is not None:
            for wy in range(top+9,base+40,13):
                for wx in range(x+4,x+w-6,10):
                    if r.random()<winprob: wins.append((wx,wy,3,5,r.choice([1,1,1,2,3]),r.random(),r.choice('oooor')))
        x+=w+r.randint(0,3)
    if fx: fx(d,color,wins)
    return im
specials=[]
def near_fx(d,c,wins):
    # clock tower
    d.rectangle([70,120,112,H+60],fill=c); d.polygon([(64,120),(118,120),(91,58)],fill=c); d.line([(91,60),(91,34)],fill=c,width=3)
    d.rectangle([66,118,116,124],fill=c)
    specials.append((91,148,12,(255,90,40)))
    # cathedral
    d.rectangle([330,190,478,H+60],fill=c)
    d.rectangle([330,118,360,200],fill=c); d.polygon([(326,118),(364,118),(345,62)],fill=c); d.line([(345,64),(345,40)],fill=c,width=2)
    d.rectangle([448,118,478,200],fill=c); d.polygon([(444,118),(482,118),(463,62)],fill=c); d.line([(463,64),(463,40)],fill=c,width=2)
    d.polygon([(362,190),(446,190),(404,148)],fill=c)
    specials.append((404,206,14,(255,60,40)))
    for ax in (345,463):
        for ay in (140,165): wins.append((ax-2,ay,4,9,2,ax/700.0,'r'))
wm=[];wn=[]
far=skyline(11,250,50,140,26,60,(66,6,18,255),.35,None,0)
mid=skyline(22,300,70,170,24,56,(30,3,11,255),.4,wm,.28)
near=skyline(33,H+10,60,150,30,70,(8,0,10,255),.3,wn,.35,near_fx)

def draw_windows(img,wins,dx,dy,ph,sc=1.0):
    d=ImageDraw.Draw(img)
    for wx,wy,w,h,fr,pf,col in wins:
        v=math.sin(TAU*(fr*ph+pf))
        inten=(1.0 if v>-.2 else .12) if fr==3 else .5+.5*v
        inten=.25+.75*inten
        c=(255,165,55) if col=='o' else (255,40,40)
        c=tuple(int(k*inten*sc) for k in c)
        x=wx-40+dx; y=wy+dy
        d.rectangle([x,y,x+w,y+h],fill=c)

# bats
rb=random.Random(8); bats=[]
for _ in range(16):
    bats.append(dict(x0=rb.uniform(0,EW),dir=rb.choice([-1,1]),k=rb.choice([1,1,2]),y0=rb.uniform(25,230),ay=rb.uniform(6,26),ny=rb.choice([1,2]),py=rb.uniform(0,TAU),s=rb.uniform(6,16),m=rb.choice([18,24,30]),pm=rb.uniform(0,TAU)))
def draw_bat(d,cx,cy,s,fl):
    col=(4,0,6,255)
    L=[(cx-1,cy),(cx-.5*s,cy-.35*s-.35*s*fl),(cx-1.25*s,cy-.7*s*fl),(cx-1.0*s,cy-.7*s*fl+.35*s),(cx-.75*s,cy+.05*s),(cx-.5*s,cy+.35*s),(cx-.2*s,cy+.1*s)]
    Rr=[(2*cx-x,y) for x,y in L]
    d.polygon(L,fill=col); d.polygon(Rr,fill=col)
    d.ellipse([cx-.17*s,cy-.35*s,cx+.17*s,cy+.4*s],fill=col)
    d.polygon([(cx-.15*s,cy-.3*s),(cx-.2*s,cy-.6*s),(cx-.02*s,cy-.35*s)],fill=col)
    d.polygon([(cx+.15*s,cy-.3*s),(cx+.2*s,cy-.6*s),(cx+.02*s,cy-.35*s)],fill=col)

# bolt path
rbo=random.Random(4); bx,by=232,-5; bolt=[(bx,by)]
for i in range(9):
    bx+=rbo.randint(-14,14)+2; by+=rbo.randint(14,22); bolt.append((bx,by))
branch=[bolt[4],(bolt[4][0]+30,bolt[4][1]+22),(bolt[4][0]+44,bolt[4][1]+52)]

vig=np.clip(1-.6*(((X-.5)*1.3)**2+((Y-.5)*1.1)**2),0,1)[...,None]
cmd=['ffmpeg','-y','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','-',
     '-c:v','libx264','-preset','slow','-crf','26','-pix_fmt','yuv420p','-movflags','+faststart','-an','city.mp4']
pr=subprocess.Popen(cmd,stdin=subprocess.PIPE)
for i in range(N):
    ph=i/N
    f=0.0
    for c,amp in ((0.50,1.0),(0.535,.6)):
        dt=ph-c
        if 0<=dt<.05: f+=amp*math.exp(-dt*90)
    arr=sky.copy()
    arr+=glow*(.8+.35*math.sin(TAU*2*ph))
    for sx_,sy_,sz,sp in stars:
        v=.35+.65*(.5+.5*math.sin(TAU*(1+int(sp*3))*ph+sp*6))
        arr[sy_:sy_+sz,sx_:sx_+sz]=np.maximum(arr[sy_:sy_+sz,sx_:sx_+sz],255*v*np.array([1,.8,.8]))
    cl=np.clip((field(CA,X+.15*ph*0+.12*np.sin(TAU*ph+Y*3),Y,ph)-.05)*3.2,0,1)*.75
    cl=cl[...,None]*(1-np.clip(Y*1.2,0,1)[...,None]*0)  # wisps
    mcol=mooncol*(1-cl*.8)
    dk=disk[...,None]
    arr=arr*(1-dk)+mcol*dk
    arr+=f*np.array([110,90,100],np.float32)*(1-.5*Y)[...,None]
    img=Image.fromarray(np.clip(arr,0,255).astype(np.uint8),'RGB')
    img.paste(far,(-40+int(round(6*math.sin(TAU*ph))),int(round(2*math.sin(TAU*ph+1)))),far)
    dxm=int(round(14*math.sin(TAU*ph+.5))); dym=int(round(4*math.sin(TAU*ph+2)))
    img.paste(mid,(-40+dxm,dym),mid)
    draw_windows(img,wm,dxm,dym,ph,.8)
    a2=np.asarray(img).astype(np.float32)
    wx_=X+.12*field(FB,X,Y,ph); wy_=Y+.12*field(FB,Y,X,ph+.37)
    fg=np.clip(field(FA,wx_,wy_,ph)*.5+.5,0,1)**1.5
    al=(fg*(Y**2.0)*.6)[...,None]
    a2=a2*(1-al)+np.array([170,34,46],np.float32)*al
    img=Image.fromarray(np.clip(a2,0,255).astype(np.uint8),'RGB')
    d=ImageDraw.Draw(img,'RGBA')
    for b in bats:
        px=((b['x0']+b['dir']*b['k']*EW*ph)%EW)-40
        py=b['y0']+b['ay']*math.sin(TAU*b['ny']*ph+b['py'])
        draw_bat(d,px,py,b['s'],math.sin(TAU*b['m']*ph+b['pm']))
    if .5<=ph<.53:
        d.line(bolt,fill=(255,70,70,200),width=6); d.line(branch,fill=(255,70,70,160),width=4)
        d.line(bolt,fill=(255,235,235,255),width=2); d.line(branch,fill=(255,235,235,230),width=1)
    dxn=int(round(26*math.sin(TAU*ph+1))); dyn=int(round(6*math.sin(TAU*ph)))
    img.paste(near,(-40+dxn,dyn),near)
    draw_windows(img,wn,dxn,dyn,ph,1.0)
    d=ImageDraw.Draw(img,'RGBA')
    for sx_,sy_,sr,col in specials:
        pulse=.75+.25*math.sin(TAU*2*ph)
        c=tuple(int(k*pulse) for k in col)
        cx,cy=sx_-40+dxn,sy_+dyn
        d.ellipse([cx-sr,cy-sr,cx+sr,cy+sr],fill=c+(255,))
        d.line([(cx,cy-sr),(cx,cy+sr)],fill=(40,0,0,255),width=1); d.line([(cx-sr,cy),(cx+sr,cy)],fill=(40,0,0,255),width=1)
    a3=np.asarray(img).astype(np.float32)
    al2=(fg*(Y**3.0)*.35)[...,None]
    a3=a3*(1-al2)+np.array([150,30,40],np.float32)*al2
    # bloom
    br=np.clip(a3-170,0,255).astype(np.uint8)
    bl=np.asarray(Image.fromarray(br,'RGB').filter(ImageFilter.GaussianBlur(7))).astype(np.float32)
    a3=a3+bl*1.1
    a3=a3*vig
    pr.stdin.write(np.clip(a3,0,255).astype(np.uint8).tobytes())
pr.stdin.close();pr.wait()
print(os.path.getsize('city.mp4'))
