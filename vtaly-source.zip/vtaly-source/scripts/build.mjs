#!/usr/bin/env node
/**
 * Build: copies src/ to dist/ and also writes dist/index.single.html,
 * a self-contained copy with all CSS, JS and media inlined (easy to share or host anywhere).
 * Uses only Node built-ins, so `npm install` is not required to build.
 */
import { cpSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { dirname, extname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const src = join(root, 'src');
const dist = join(root, 'dist');
const MIME = { '.mp3': 'audio/mpeg', '.mp4': 'video/mp4' };
const read = (path) => readFileSync(join(src, path), 'utf8');

rmSync(dist, { recursive: true, force: true });
mkdirSync(dist, { recursive: true });
cpSync(src, dist, { recursive: true });

let html = read('index.html');

// CSS files load in numeric order; inline them in the same order.
html = html.replace(/<link rel="stylesheet" href="(css\/[^"]+)">/g, (_, path) => `<style>\n${read(path)}</style>`);

// Deferred scripts become inline scripts at the end of <body>, preserving order.
const scripts = [];
html = html.replace(/<script defer src="(js\/[^"]+)"><\/script>\s*/g, (_, path) => {
  scripts.push(read(path));
  return '';
});
html = html.replace('</body>', () => `${scripts.map((code) => `<script>\n${code}</script>`).join('\n')}\n</body>`);

// Media files become data URIs.
html = html.replace(/src="(assets\/[^"]+)"/g, (_, path) => {
  const data = readFileSync(join(src, path)).toString('base64');
  return `src="data:${MIME[extname(path)]};base64,${data}"`;
});

writeFileSync(join(dist, 'index.single.html'), html);
console.log(`Built dist/ and dist/index.single.html (${(html.length / 1e6).toFixed(1)} MB)`);
