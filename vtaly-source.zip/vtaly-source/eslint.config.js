// Starter config: classic scripts sharing one namespace (window.VT).
const globals = Object.fromEntries(
  ['window', 'document', 'navigator', 'localStorage', 'performance', 'requestAnimationFrame',
   'setTimeout', 'setInterval', 'Event', 'URL', 'Uint8Array'].map((name) => [name, 'readonly']),
);

export default [
  {
    files: ['src/js/**/*.js'],
    languageOptions: { ecmaVersion: 2022, sourceType: 'script', globals: { ...globals, VT: 'writable' } },
    rules: { 'no-undef': 'error', 'no-unused-vars': 'warn' },
  },
];
