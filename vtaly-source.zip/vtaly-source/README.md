# vtaly bio page

A single-page vampire bio site built with plain HTML, CSS and vanilla JavaScript.
No framework and no runtime dependencies. Node is only used for the dev server and the build.

## Quick start
```bash
npm run dev      # http://localhost:5173 (serves src/, supports audio/video seeking)
npm run build    # writes dist/ and dist/index.single.html (everything inlined, ~3 MB)
npm run format   # Prettier (run `npm install` once first)
npm run lint     # ESLint starter config
```
`npm run dev` and `npm run build` need no `npm install`.

## Layout
```
src/
  index.html          semantic markup, loads CSS and JS in order
  css/01..10-*.css    cascade-ordered layers (load order matters)
  js/00..16-*.js      one file per feature, classic deferred scripts
  assets/             song.mp3, bg.mp4
scripts/              build.mjs, dev.mjs
tools/                make_city_video.py (generates assets/bg.mp4)
vercel.json           build command, cache and security headers
```

## Conventions
- **State:** shared values live on `window.VT` (`level`, `busy`, `gain`, `muted`) in `js/00-state.js`.
- **Events:** the entry gate dispatches `vtopen` on `document` once the bat swarm has revealed the page.
  Effects that should wait for the reveal listen for it.
- **Motion:** every animated feature checks `prefers-reduced-motion` and falls back to a static state.
- **Load order:** scripts are `defer`red and run in numeric order, so a file may rely on the ones before it.

## Easy edits
- Name: `data-t="vtaly"` and the text in `<span id="nm">` (`src/index.html`); the fonts the bite cycles through are in `10-bite-fangs.js`.
- Bio words: the `<b class="pt">` elements. Badges: the `.badges` block (`data-tip` is the tooltip).
- Links: NameMC URL and Discord username in `index.html` and `04-discord-copy.js`.
- Background video: `python3 tools/make_city_video.py` (needs numpy, pillow, ffmpeg), then move `city.mp4` to `src/assets/bg.mp4`.

## Deploy
Vercel: import the repo. `vercel.json` already sets the build command and output directory.
Any static host: upload `dist/` (or just `dist/index.single.html`).

## Keyboard shortcuts
`B` bite, `P` paint, `M` mute. The progress bar is clickable.

## Honest limitations
- The CSS is split into cascade-ordered layers, not yet consolidated: later files override earlier ones.
- JS files are classic scripts sharing `window.VT`, not ES modules. There are no automated tests.
- Next steps if this grows: merge the CSS layers, convert to ES modules with a small event bus, add Playwright smoke tests.
- You must have the right to use `assets/song.mp3` publicly.
